# 🧾 Documento Técnico — SisUno v0.6.1  
**Projeto:** Sistema de Gestão Integrado *SisUno*  
**Fase:** Consolidação — Orçamentos Integrados  
**Data:** 06/11/2025  
**Responsável:** Restaurador Officina  

---

## 🔹 1. Escopo da Versão v0.6.1
Esta atualização tem como foco a **reconstrução e validação final** das tabelas `orcamentos` e `orcamento_itens`, concluindo a fase de integração com prontuários e preparando o sistema para a geração de documentos e relatórios
